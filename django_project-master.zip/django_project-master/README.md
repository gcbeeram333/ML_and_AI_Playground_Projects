# django_project
Django Practice Project
