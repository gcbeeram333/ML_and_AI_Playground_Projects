# JIRA_PYTHON_API
JIRA Automation

JIRA Python API Documentation: [REST API v2](https://developer.atlassian.com/cloud/jira/platform/rest/v2/api-group-issue/)
