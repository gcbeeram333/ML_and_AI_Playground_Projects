# KING-COUNTY-HOUSE-PRICES-REDICTION-MODEL
Data Source:

Daya Preprocessing

Data Visualization

Predictive Modeling

Model Implementation
