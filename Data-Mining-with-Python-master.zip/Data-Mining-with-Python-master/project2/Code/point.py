class Point:
    def __init__(self, point=None, id=-1, cluster=-1):
        self.point = point
        self.cluster = cluster
        self.id = id