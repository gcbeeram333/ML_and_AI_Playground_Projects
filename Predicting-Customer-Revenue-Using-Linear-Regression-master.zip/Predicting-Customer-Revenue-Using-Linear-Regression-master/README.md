# Predicting-Customer-Revenue-Using-Linear-Regression
The model will generalize to future years to predict the next year spending behavior in advance, unless the market or business changed significantly
