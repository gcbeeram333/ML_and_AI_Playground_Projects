# CLASS_IMBALANCE
Dealing with class imbalance using SMOTE() Function
